import email
import os
import imaplib
import string
import time
import re
import paho.mqtt.client as mqtt
from flask import Flask
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, select
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.automap import automap_base
from urllib import parse

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///testing.db'

db=SQLAlchemy(app)

Base= automap_base()
Base.prepare(db.engine, reflect=True)
Email = Base.classes.email
Ipsettings=db.Table('Ipsettings', db.metadata, autoload= True, autoload_with=db.engine)

results = db.session.query(Email).all()
Results = db.session.query(Ipsettings).all()

global p,l,m,k,j;
global x,y,z;

'''

if Results != None:
    for r in Results:
        k=r.id
        if k==1:
            p=r.interface
            print(p)
            l=r.ipaddress
            print(l)
            m=r.subnet
            print(m)
            k=r.gateway
            print(k)
            j=r.dns
            print(j)
    
    if ((len(p) ==0 or len(l) ==0) or (len(m)==0 or len(k)==0)) or len(j) == 0:
        #file.write("static ip_address= 192.168.0.250/24 \n")
        #file.close()
        pass

    else:
        
        file = open('/etc/dhcpcd.conf', 'w',encoding = 'utf-8')
        file.write("interface" + " " + p + "\n"+
                   "static ip_address=" + l+ "/24" + "\n"+
                   "static routers=" + " " + k+ "\n"+
                   "static domain_name_servers=" + " " + j);

        file.close()

# else:
#    file = open('/etc/dhcpcd.conf', 'w',encoding = 'utf-8')
    
    file.write("""interface eth0 \n
                static ip_address= 192.168.0.113/24 \n
                static routers= 192.168.0.1 \n
                static domain_name_servers=192.168.0.1 8.8.8.8 """)
    
#    file.write("static ip_address= 192.168.0.113/24 \n")
    
#    file.close()

'''

for r in results:
    k=r.id
    #print(k)
    if k==1:
        x=r.email
        print(x)
        p=r.password
        #print(p)
        y=r.topic
        #print(y)
        z=r.domain
        #print(z)


EMAIL = x
PASSWORD = p
SERVER = 'imap.gmail.com'
chunks=z.split(',')
#print(chunks)


mail = imaplib.IMAP4_SSL(SERVER)
mail.login(EMAIL, PASSWORD)
mail.select('inbox')
status, data = mail.search(None, '(UNSEEN)')
mail_ids = []
for block in data:
    mail_ids = block.split()

for i in mail_ids:
    status, data = mail.fetch(i, '(RFC822)')
    for response_part in data:
        if isinstance(response_part, tuple):
            message = email.message_from_bytes(response_part[1])
            mail_from = message['from']
            mail_subject = message['subject']
            
            
            #print ("From:",mail_from)
            #print ("Subject:",mail_subject)
            if message.is_multipart():
                mail_content = ''
                #f1= parse.splituser(mail_from)[1]
                start=mail_from.find("@")+ len("@")
                end=mail_from.find(">")
                f1=mail_from[start:end]
                #print(f1)
                
                if f1 in chunks:
                    if (mail_subject == y):
                        #print("subject and domain")
                        
                        mqttc=mqtt.Client()
                        #print(l)
                        mqttc.connect(l, 1883)
                        
                        for part in message.get_payload():
                            if part.get_content_type() == 'text/plain':
                                mail_content += part.get_payload()
                                mqttc.publish(y, mail_content)
                                #print("Body:",mail_content)
                        
                            else:
                                #print("sub not matched")
                                pass
                    else:
                           #print("domain not matched")
                        pass
                            
            else:
                mail_content = message.get_payload()
                print(mail_content)



                


