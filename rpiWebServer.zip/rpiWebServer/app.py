import sqlite3

from flask import Flask, render_template, request, redirect, url_for, current_app, session, json
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import paho.mqtt.client as mqtt

app = Flask(__name__)
app._static_folder = '/home/pi/Documents/rpiWebServer/static'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///testing.db'
app.config['SECRET_KEY'] = 'hardestsecretkeyever'
# app.config['Server_Name']= 'mqttmessages.com'
# Initialize the database
db = SQLAlchemy(app)


# print url_for('about', _external= True)

class Ipsettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    interface = db.Column(db.String(200), nullable=False)
    ipaddress = db.Column(db.String(200), nullable=False)
    subnet = db.Column(db.String(200), nullable=False)
    gateway = db.Column(db.String(200), nullable=False)
    dns = db.Column(db.String(500), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"Ipsettings('{self.interface} {self.ipaddress}', {self.subnet}' , '{self.gateway}', '{self.dns}')"


class Email(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(200), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    topic = db.Column(db.String(200), nullable=False)
    domain = db.Column(db.String(500), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"Email('{self.email}', {self.password}' , '{self.topic}', '{self.domain}')"


# Create db model
class Mqtt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ids = db.Column(db.Integer)
    name = db.Column(db.String(200), default=' ')
    m1 = db.Column(db.String(200), default=' ')
    m2 = db.Column(db.String(200), default=' ')
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    # Create a function to return string when we add something
    def __repr__(self):
        return '<Topic %r>' % self.id


# Create db model
class Mqtt_user(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(200), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    # Create a function to return string when we add something
    def __repr__(self):
        return f"Mqtt_user('{self.username}', {self.password}')"


db.create_all()
Topics = []

r = db.session.query(Mqtt).count()
Rows = db.session.query(Email).count()
Row = db.session.query(Ipsettings).count()

if r == 0:
    objects = [Mqtt(ids="0", name="CaretakerMessage", m1="caretakerMessage" ),
               Mqtt(ids="1", name= "FireAlarm", m1= "FireAlarm activated", m2="FireAlarm deactivated"),
               Mqtt(ids="2"), Mqtt(ids="3"), Mqtt(ids="4"),
               Mqtt(ids="5"), Mqtt(ids="6"), Mqtt(ids="7"), Mqtt(ids="8"), Mqtt(ids="9"),
               Mqtt(ids="10")]
    db.session.add_all(objects)
    db.session.commit()


@app.route('/ipsettings', methods=['POST', 'GET'])
def ipsettings():
    title = "Raspberry pi ip settings"
    Row = db.session.query(Ipsettings).count()

    if Row == 1:
        error_statement = "You can only add one"
        ncs = Ipsettings.query.order_by(Ipsettings.date_created)
        return render_template("ipsettings.html", error_statement=error_statement, ncs=ncs)

    elif request.method == 'POST':
        # return "You clicked the button, so is this.."
        interface = request.form['interface']
        ip_address = request.form['ip_address']
        subnet = request.form['subnet']
        gateway = request.form['gateway']
        dns_server = request.form['dns']
        new_settings = Ipsettings(interface=interface, ipaddress=ip_address, subnet=subnet, gateway=gateway,
                                  dns=dns_server)
        # push to Database
        try:
            db.session.add(new_settings)
            db.session.commit()
            return redirect('/ipsettings')
        except:
            return "There was an error adding ip settings"

    else:
        ncs = Ipsettings.query.order_by(Ipsettings.date_created)
        return render_template("ipsettings.html", title=title, ncs=ncs)


@app.route('/dns/<int:id>', methods=['POST', 'GET'])
def dns(id):
    dns_to_update = Ipsettings.query.get_or_404(id)
    if request.method == "POST":
        dns_to_update.interface = request.form['interface']
        dns_to_update.ipaddress = request.form['ip_address']
        dns_to_update.subnet = request.form['subnet']
        dns_to_update.gateway = request.form['gateway']
        dns_to_update.dns = request.form['dns']
        try:
            db.session.commit()
            return redirect('/ipsettings')
        except:
            return "There was a problem updating"
    else:
        return render_template('dns.html', dns_to_update=dns_to_update)


@app.route('/email', methods=['POST', 'GET'])
def email():
    title = "Email Subscription Details"
    Rows = db.session.query(Email).count()

    if Rows == 1:
        error_statement = "You can only add one"
        ncs = Email.query.order_by(Email.date_created)
        return render_template("email.html", error_statement=error_statement, ncs=ncs)

    elif request.method == 'POST':
        # return "You clicked the button, so is this.."
        email_id = request.form['email_id']
        password = request.form['password']
        topic_name = request.form['topic_name']
        domain_name = request.form['domain_name']
        new_domain = Email(email=email_id, password=password, topic=topic_name, domain=domain_name)
        '''
            if not email_id or not password or not topic_name or not domain_name :
                error_statement = "All Form Fields Required..."
                return render_template("email.html", error_statement= error_statement, email_id=email_id, password=password, topic_name=topic_name, domain_name=domain_name)
        '''
        # push to Database
        try:
            db.session.add(new_domain)
            db.session.commit()
            return redirect('/email')
        except:
            return "There was an error adding Email subscription details"

    else:
        ncs = Email.query.order_by(Email.date_created)
        return render_template("email.html", title=title, ncs=ncs)


@app.route('/domain/<int:id>', methods=['POST', 'GET'])
def domain(id):
    domain_to_update = Email.query.get_or_404(id)
    if request.method == "POST":
        domain_to_update.email = request.form['email_id']
        domain_to_update.password = request.form['password']
        domain_to_update.topic = request.form['topic_name']
        domain_to_update.domain = request.form['domain_name']
        try:
            db.session.commit()
            return redirect('/email')
        except:
            return "There was a problem updating"
    else:
        return render_template('domain.html', domain_to_update=domain_to_update)


@app.route('/secure_mqtt/<int:id>', methods=['POST', 'GET'])
def secure_mqtt(id):
    topic_to_update = Mqtt.query.get_or_404(id)
    data = Mqtt_user.query.all()
    msg = ''
    # result = session.query(Mqtt_user.id).all()

    print(data)

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        result = db.session.query(Mqtt_user.username)
        result1 = db.session.query(Mqtt_user.password)
        if username in result[0] and password in result1[0]:
            return render_template('update.html', topic_to_update=topic_to_update)
        else:
            msg = 'Invalid username/password!'

    return render_template('secure_mqtt.html', msg=msg, topic_to_update=topic_to_update)


@app.route('/update/<int:id>', methods=['POST', 'GET'])
def update(id):
    topic_to_update = Mqtt.query.get_or_404(id)
    if request.method == "POST":
        topic_to_update.name = request.form['name']
        topic_to_update.m1 = request.form['name1']
        topic_to_update.m2 = request.form['name2']
        try:
            db.session.commit()
            return redirect('/topics')
        except:
            return "There was a problem updating"
    else:
        return render_template('update.html', topic_to_update=topic_to_update)


@app.route('/edit/<int:id>', methods=['POST', 'GET'])
def edit(id):
    mqtt_user_to_update = Mqtt_user.query.get_or_404(id)
    if request.method == "POST":
        mqtt_user_to_update.username = request.form['username']
        mqtt_user_to_update.password = request.form['password']
        try:
            db.session.commit()
            return redirect('/topics')
        except:
            return "There was a problem updating"
    else:
        return render_template('edit.html', mqtt_user_to_update=mqtt_user_to_update)


@app.route('/mqtt_user', methods=['POST', 'GET'])
def mqtt_user():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        new_mqtt_user = Mqtt_user(username=username, password=password)
        try:
            db.session.add(new_mqtt_user)
            db.session.commit()
            return redirect('/topics')
        except:
            return "There was an error adding Email subscription details"

    return render_template('mqtt_user.html')


@app.route('/trigger', methods=['POST', 'GET'])
def trigger():
    status = ''
    conn = sqlite3.connect('testing.db')
    print("Opened database successfully")
    c = conn.cursor()
    c = c.execute("SELECT * from Mqtt_user where id = 1")
    res = c.fetchone()
    username = res[1]
    password = res[2]
    print(username, password)

    try:
        client = mqtt.Client()
        client.username_pw_set(username, password)
        client.connect("localhost", 1883)
        # print("Button pressed!")
        client.publish("caretakerMessage", "Message Published!")
        client.disconnect()
        status = 'Published Successfully'
    except:
        return "Error Publishing"
    return redirect('/topics', )


@app.route('/topics', methods=['POST', 'GET'])
def topics():
    r1 = db.session.query(Mqtt_user).count()
    # print(r1)

    if r1 == 0:
        return redirect('/mqtt_user')

    else:

        title = "Topics and Messages List"
        pins = ["Default", "GPIO32", "GPIO36", "GPIO37", "GPIO38", "GPIO40", "GPIO15", "GPIO29", "GPIO31", "GPIO33",
                "GPIO35"]
        '''
        if rows >= 10:
            error_statement = "You can add only 10 fields"
            friends = Mqtt.query.order_by(Mqtt.date_created)
            print(friends)
            return render_template("topics.html", error_statement=error_statement, friends=friends, pins=pins)
    
    
        elif request.method == 'POST':
            # return "You clicked the button, so is this.."
            topic_name = request.form['name']
            message_1 = request.form['name1']
            message_2 = request.form['name2']
            new_topic = Mqtt(name=topic_name, m1=message_1, m2=message_2)
            # push to Database
            try:
                db.session.add(new_topic)
                db.session.commit()
                return redirect('/topics')
            except:
                return "There was an error adding Topics"
        '''

        friends = Mqtt.query.order_by(Mqtt.date_created)
        records = Mqtt_user.query.order_by(Mqtt_user.date_created)
        return render_template("topics.html", title=title, friends=friends, pins=pins, records=records)


@app.route('/index', methods=['POST', 'GET'])
def index():
    title = "Topics and Messages"
    return render_template("index.html", title=title)


@app.route('/about')
def about():
    title = """	Network Communication Systems Limited (NCS), designed an easy to use lightweight website for the users to manage their individual site sensors activities with the help of MQTT. So that, based on the condition whenever the particular sensor state will change with the help of SBC it will generate an MQTT message to all the devices connected with the server.  So that it can alert the situation. \n """
    title1 = """	MQTT is a Wireless protocol which used for IOT Application to publish and subscribe messages between the client and Server. As in MQTT one can decide a Server and multiple clients, all of which will be connected with that particular Server which gets the messages whenever something is published from the Server side with dedicated topic name. \n"""

    title2 = """	The SBC have 10 dedicated input/output pins which are open to connect with 10 different peripherals which can connect with SBC (Hardware). On the Website, the user can decide an each topic name for each peripherals and each topic can have two different message types which will indicate as normal state and faulty state based on the condition which will be applied. Out of 10 Input/output pins 5 input/output pins will act as open circuit state and remaining 5 will act as close circuit state, So, based on the state change registered users will get messages through MQTT which can be decided on the website for both the states i.e; Faulty and Normal. So that the user can know the status of the peripherals state. \n"""

    return render_template("about.html", title=title, title1=title1, title2=title2)


@app.route('/form', methods=["POST"])
def form():
    topic_name = request.form.get("topic_name")
    message_1 = request.form.get("message_1")
    if not topic_name or not message_1:
        error_statement = "All Form Fields Required..."
        return render_template("subscribe.html", error_statement=error_statement, topic_name=topic_name,
                               message_1=message_1)

    Topics.append(f" {topic_name} {message_1}")
    title = "Thank You!"
    return render_template("form.html", title=title, Topics=Topics)


@app.route('/', methods=['POST', 'GET'])
def login():
    msg = ''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'Admin' and password == '01NCS09':
            msg = 'Logged in Successfully!'
            return render_template('index.html')
        else:
            msg = 'Invalid username/password!'

    return render_template('login.html', msg=msg)


@app.route('/logout')
def logout():
    # response.headers.add('Cache-Control', 'no-store , no-cache , must-revalidate, post-check=0, pre-check=0')
    return redirect('/')


@app.after_request
def after_request(response):
    response.headers.add('Cache-Control', 'no-store , no-cache , must-revalidate, post-chevk=0, pre-check=0')
    # response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, post-check=0, pre-check=0 "
    return response


if __name__ == "__main__":
    app.run(host='localhost', port=5000, debug=True)
    '''
    website_url = 'ncsportal05.controllingaccess.com:443'
    app.config['SERVER_NAME'] = website_url
    context = ('/home/pi/Downloads/ssl_certificate.cer', '/home/pi/Downloads/private-key.key')
    app.run(ssl_context=context, debug=True)
    '''
