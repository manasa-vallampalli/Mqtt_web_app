from multiprocessing import Process
from subprocess import call


def loop_a():
     call(["python3", "/home/pi/Documents/rpiWebServer/app.py"]) 

def loop_b():
        call(["python3", "/home/pi/Documents/rpiWebServer/subscribe.py"])
        
'''
def loop_c():
    while 1:
        call(["python3", "/home/pi/Documents/rpiWebServer/receive_email.py"]) &

'''

if __name__ == '__main__':
    Process(target=loop_a).start()
    Process(target=loop_b).start()
    #Process(target=loop_c).start()
    
