import paho.mqtt.client as mqtt
import RPi.GPIO as GPIO
from flask import Flask
import sqlite3
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, select
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.automap import automap_base
import time

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////home/pi/Documents/rpiWebServer/testing.db'

db = SQLAlchemy(app)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(32, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(36, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(37, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(38, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(40, GPIO.IN, pull_up_down=GPIO.PUD_UP)

GPIO.setup(15, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(29, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(31, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(33, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(35, GPIO.IN, pull_up_down=GPIO.PUD_UP)

Mqtt = db.Table('Mqtt', db.metadata, autoload=True, autoload_with=db.engine)
Base = automap_base()
Base.prepare(db.engine, reflect=True)
# Mqtt = Base.classes.mqtt

results = db.session.query(Mqtt).all()
# print(results)

global flag, z

flag = 1
flag1 = 1
flag2 = 1
flag3 = 1
flag4 = 1

flag5 = 1
flag6 = 1
flag7 = 1
flag8 = 1
flag9 = 1

conn = sqlite3.connect('/home/pi/Documents/rpiWebServer/testing.db')
print("Opened database successfully")
c = conn.cursor()
c = c.execute("SELECT * from mqtt_user where id = 1")
res = c.fetchone()
username = res[1]
password = res[2]
print(username, password)

while (1):

    client = mqtt.Client()
    client.username_pw_set(username, password)
    client.connect("192.168.0.141", 1883)

    if GPIO.input(32) == GPIO.LOW:
        i = 0
        if (flag == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 2:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag = 0

    if GPIO.input(32) == GPIO.HIGH:
        if (flag == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 2:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag = 1

    # =====================================================================

    if GPIO.input(36) == GPIO.LOW:
        i = 0
        if (flag1 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 3:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag1 = 0

    if GPIO.input(36) == GPIO.HIGH:
        if (flag1 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 3:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag1 = 1

    # =====================================================================

    if GPIO.input(37) == GPIO.LOW:
        i = 0
        if (flag2 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 4:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag2 = 0

    if GPIO.input(37) == GPIO.HIGH:
        if (flag2 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 4:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag2 = 1

    # ===================================================================
    if GPIO.input(38) == GPIO.LOW:
        i = 0
        if (flag3 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 5:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag3 = 0

    if GPIO.input(38) == GPIO.HIGH:
        if (flag3 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 5:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag3 = 1

    # =====================================================================

    if GPIO.input(40) == GPIO.LOW:
        i = 0
        if (flag4 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 6:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag4 = 0

    if GPIO.input(40) == GPIO.HIGH:
        if (flag4 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 6:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag4 = 1

    # =====================================================================

    if GPIO.input(15) == GPIO.HIGH:
        i = 0
        if (flag5 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 7:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag5 = 1

    if GPIO.input(15) == GPIO.LOW:
        if (flag5 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 7:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag5 = 0

    # =====================================================================

    if GPIO.input(29) == GPIO.HIGH:
        i = 0
        if (flag6 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 8:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag6 = 1

    if GPIO.input(29) == GPIO.LOW:
        if (flag6 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 8:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag6 = 0

    # =====================================================================

    if GPIO.input(31) == GPIO.HIGH:
        i = 0
        if (flag7 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 9:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag7 = 1

    if GPIO.input(31) == GPIO.LOW:
        if (flag7 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 9:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag7 = 0

    # =====================================================================

    if GPIO.input(33) == GPIO.HIGH:
        i = 0
        if (flag8 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 10:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag8 = 1

    if GPIO.input(33) == GPIO.LOW:
        if (flag8 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 10:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag8 = 0

    # =====================================================================

    if GPIO.input(35) == GPIO.HIGH:
        i = 0
        if (flag9 == 0):
            for r in results:
                k = r.id
                # print(k)
                if k == 11:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, y, 0, False)
                        client.disconnect()
                        print("Button pressed!")
                        flag9 = 1

    if GPIO.input(35) == GPIO.LOW:
        if (flag9 == 1):
            for r in results:
                k = r.id
                # print(k)
                if k == 11:
                    x = r.name
                    p = x.lstrip()
                    print(p)
                    y = r.m1
                    # print(y)
                    z = r.m2
            if len(x) == 0:
                pass
            else:
                i = 0
                while (i <= 100):
                    i = i + 1
                    if (i >= 100):
                        client.publish(p, z, 0, False)
                        client.disconnect()
                        print("Disconnected!")
                        flag9 = 0
                        
                        
                        
                        
                        
                        
                        
                        

