#!/bin/sh

sudo mosquitto
