import mysql.connector

'''
mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    passwd='mysql',
)

my_cursor = mydb.cursor()

# my_cursor.execute("CREATE DATABASE new_table")

my_cursor.execute("SHOW DATABASES")
l = []
for db in my_cursor:
    # print(db)
    l.append(db[0])
    # print(db[0])

print(l)

x = "innoart"
my_cursor.execute("use" + " " + x)
my_cursor.execute("show tables")

t =[]
for y in my_cursor:
    t.append(y[0])
    print(y[0])

print(t)

k = "users_data"
l=[]


my_cursor.execute("select * from" + " " + k)
for i in my_cursor:
    l.append(i)
    print(i)

print(l)

for k in l:
        print(k[0])
        '''

'''
my_cursor.execute("select * from" + " " + k)

for i in my_cursor:
    print(i)

'''

x = "b'int'"
y = x.strip("b'")
print(y)
