from collections import defaultdict
ll_ = ['2a', 'sipengine', '1', '0 = not present, 1 = present']

dt_ = ['int', 'text', 'int', 'text']


my_list = ['int', 'text', 'int', 'text']
all_indexes = []
for i in range(0, len(my_list)):
    if my_list[i] == 'int' :
        all_indexes.append(i)
print("Originallist ", my_list)
print("Indexes int: ", all_indexes)

for i in all_indexes:
    y= ll_[i]
    print(y)
    if y.isdigit():
        pass
    else:
        print("alert")




