import decorator
from flask import Flask, render_template, request, redirect, url_for, current_app, session, flash
from flask_mysqldb import MySQL
import mysql.connector
from datetime import datetime
from flask import Response

app = Flask(__name__)
app._static_folder = '/home/pi/Documents/Innoart/static'
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql://root:mysql@localhost"
app.config['SECRET_KEY'] = "secret_key"

mydb = mysql.connector.connect(
    host='localhost',
    user='root',
    passwd='mysql',
)


@app.route('/update', methods=['POST', 'GET'])
def update():
    if request.method == 'POST':
        if request.form.get("logout"):
            return redirect('/')
        elif request.form.get("submit"):
            tableName = request.form['table_name']
            dbname = request.form['database_name']
            id_ = request.form['id']
            names_ = request.form.getlist('names')
            column_names = request.form.getlist('column_names')
            datatype_ = request.form.getlist('datatype_')
            first_c = column_names[0]
            # print(first_c)
            print(datatype_)
            res = {}
            for key in column_names:
                for value in names_:
                    res[key] = value
                    names_.remove(value)
                    break
            print(res)
            example_list = []
            empty = ""
            dt_list = []
            for key, value in res.items():
                example = key + "= " + "'" + value + "'"
                empty = empty + ", " + example
                example_list.append(example)
                dt_list.append(value)
            print(example_list)
            print(dt_list)
            all_indexes = []
            for i in range(0, len(datatype_)):
                if datatype_[i] == 'int':
                    all_indexes.append(i)
            print("Originallist ", datatype_)
            print("Indexes int: ", all_indexes)

            for i in all_indexes:
                y = dt_list[i]
                print(y)
                if y.isdigit():
                    print("cool!")
                    attach = empty.lstrip(",")
                    print(empty.lstrip(","))
                    my_cursor = mydb.cursor()
                    query = "update " + tableName + " set" + attach + " where " + first_c + " = " + id_ + ";"
                    print(query)
                    my_cursor.execute(query)
                    mydb.commit()
                    my_cursor.close()
                    return redirect(url_for('data', value1=tableName, value=dbname))
                else:
                    tableName = request.form['table_name']
                    dbname = request.form['database_name']
                    id_ = request.form['id']
                    # ids = request.args.get('ids', None)
                    ids = request.form['column_names']
                    print(dbname, tableName, id_, ids)
                    my_cursor = mydb.cursor()
                    my_cursor.execute("show columns from " + tableName)
                    column_names = []
                    data_type = []
                    null = []
                    # types = {'int': 'Numeric', 'varchar': 'All chars', 'text': 'All chars'}
                    for i in my_cursor:
                        column_names.append(i[0])
                        data_type.append(str(i[1]).strip("b'"))
                        null.append(i[2])
                    print(null)
                    query = "SELECT * FROM " + tableName + " WHERE " + ids + " =" + id_
                    print(query)
                    my_cursor.execute(query)
                    update_new = my_cursor.fetchone()
                    update_ = list(update_new)
                    # print(update_)
                    res = {}
                    for key in column_names:
                        for value in update_:
                            res[key] = [value, data_type[0], null[0]]
                            update_.remove(value)
                            data_type.remove(data_type[0])
                            null.remove(null[0])
                            break
                    print(res)
                    print("alert")
                    msg = 'Invalid Input "' + ids + '". Enter a Numeric Value'
                    return render_template('update.html', msg=msg, id=id_, res=res, value1=tableName, value=dbname)
                    # return redirect(url_for('update', msg=msg))


    else:
        dbname = request.args.get('dbname', None)
        tableName = request.args.get('tableName', None)
        id_ = request.args.get('id', None)
        ids = request.args.get('ids', None)
        # print(dbname, tableName, id_, ids)
        my_cursor = mydb.cursor()
        my_cursor.execute("show columns from " + tableName)
        column_names = []
        data_type = []
        null = []
        # types = {'int': 'Numeric', 'varchar': 'All chars', 'text': 'All chars'}
        for i in my_cursor:
            column_names.append(i[0])
            data_type.append(str(i[1]).strip("b'"))
            null.append(i[2])
        print(null)
        query = "SELECT * FROM " + tableName + " WHERE " + ids + " =" + id_
        print(query)
        my_cursor.execute(query)
        update_new = my_cursor.fetchone()
        update_ = list(update_new)
        # print(update_)
        res = {}
        for key in column_names:
            for value in update_:
                res[key] = [value, data_type[0], null[0]]
                update_.remove(value)
                data_type.remove(data_type[0])
                null.remove(null[0])
                break
        print(res)
        return render_template('update.html', id=id_, res=res, value1=tableName, value=dbname)


@app.route('/data', methods=['POST', 'GET'])
def data():
    if request.method == 'POST':
        if request.form.get("logout"):
            return redirect('/')
        elif request.form.get("back"):
            return redirect(url_for('dbs'))
        elif request.form.get("submit"):
            tableName = request.form['table_name']
            id_ = request.form['id']
            ids = request.form['ids']
            dbname = request.form['database_name']
            # print(tableName, id_, dbname)
            return redirect(url_for('update', tableName=tableName, id=id_, dbname=dbname, ids=ids))
    else:
        value = request.args.get('value', None)
        value1 = request.args.get('value1', None)
        my_cursor = mydb.cursor()
        my_cursor.execute("show columns from " + value1)
        c = []
        for i in my_cursor:
            c.append(i[0])
        # print(c)
        my_cursor.execute("select * from " + value1)
        d = []
        for i in my_cursor:
            d.append(i)
        # print(d)
        return render_template('data.html', value1=value1, i=d, value=value, c=c)


@app.route('/table', methods=['POST', 'GET'])
def table():
    if request.method == 'POST':
        if request.form.get("logout"):
            return redirect('/')
        elif request.form.get("submit"):
            value1 = request.form['selected_table']
            value3 = request.form['database_name']
            print(value1)
            # return f"DB is {value}"
            return redirect(url_for('data', value1=value1, value=value3))
    else:
        value = request.args.get('value', None)
        my_cursor = mydb.cursor()
        my_cursor.execute("use" + " " + value)
        my_cursor.execute("show tables")
        t = []
        for y in my_cursor:
            t.append(y[0])
            # print(y[0])
        return render_template('table.html', value=value, t=t)


@app.route('/dbs', methods=['POST', 'GET'])
def dbs():
    if request.method == 'POST':
        if request.form.get("logout"):
            return redirect('/')
        elif request.form.get("submit"):
            value = request.form['selected_db']
            session["value"] = request.form['selected_db']
            print(value)
            # return f"DB is {value}"
            return redirect(url_for('table', value=value))

    else:
        msg = "Available Databases "
        my_cursor = mydb.cursor()
        my_cursor.execute("SHOW DATABASES")
        l = []
        for db in my_cursor:
            l.append(db[0])
            # print(db[0])
        my_cursor.close()
        return render_template('dbs.html', msg=msg, l=l)


@app.route('/', methods=['POST', 'GET'])
def login():
    msg = ''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'Admin' and password == '01NCS09':
            msg = 'Logged in Successfully!'
            return redirect(url_for('dbs'))
        else:
            msg = 'Invalid username/password!'

    return render_template('login.html', msg=msg)


@app.route('/logout')
def logout():
    # response.headers.add('Cache-Control', 'no-store , no-cache , must-revalidate, post-check=0, pre-check=0')
    return redirect('/')


@app.after_request
def after_request(response):
    response.headers.add('Cache-Control', 'no-store , no-cache , must-revalidate, post-chevk=0, pre-check=0')
    # response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, post-check=0, pre-check=0 "
    return response


if __name__ == "__main__":
    app.run(host='localhost', port=5000, debug=True)
